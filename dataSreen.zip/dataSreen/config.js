const SCREEN_CONFIG = {
  //请求间隔时间（暂为30分钟）
  setTimer: 18000000,
  //baseUrl
  // baseURL: "http://192.168.71.33:9123/api", //测试服务器
  baseURL: "http://60.163.192.86:8081//api", //正式外网服务器
  // baseURL2: "http://192.168.86.62:8081", //测试服务器
  baseURL2: "http://10.80.17.23:9090", //正式外网服务器
  // MapURL: "http://61.153.37.214:81/dist/index.html", //正式环境管控平台
  // MapURL: "http://192.168.71.33:8015/dist/index.html", //测试环境管控平台
  // filePath: "http://192.168.71.33:50000", //测试环境文件服务器
  filePath: "http://60.163.192.86:8081/file" //正式环境文件服务器
};
